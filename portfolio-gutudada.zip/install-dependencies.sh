# Install the required dependencies
npm install framer-motion @tabler/icons-react

# If you want to upgrade to Tailwind CSS v4 (optional)
npm install tailwindcss@next @tailwindcss/postcss@next
